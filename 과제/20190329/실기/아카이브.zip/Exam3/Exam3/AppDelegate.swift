//
//  AppDelegate.swift
//  Exam3
//
//  Created by JinBae Jeong on 29/03/2019.
//  Copyright © 2019 pino. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }
    
    /*
     
     결제 기능 미구현
     
     -- 어려웠던 점 --
     메뉴명, 가격을 데이터로 뺀다는 생각을 못헀었음
     
\
     
     */


}

