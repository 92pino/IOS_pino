/*:
 # Error Handling
 
 * Basic
 * NSError
 * LocalizedError, CustomNSError
 * Defer
 * Result
 
 by Giftbot
 */
//: [Next](@next)
