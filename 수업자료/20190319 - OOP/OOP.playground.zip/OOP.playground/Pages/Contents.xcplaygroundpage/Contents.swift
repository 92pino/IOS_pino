/*:
 # OOP : Object-Oriented Programming
 
 1. **Basic Example**
 2. **Initialize**
 3. **Property**
 4. **Practice**
 
 by Giftbot
*/
//: [Next](@next)
